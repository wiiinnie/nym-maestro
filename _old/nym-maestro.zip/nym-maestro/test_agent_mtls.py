import os
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import httpx

ROOT = Path(__file__).resolve().parent
TMP = Path(tempfile.mkdtemp())
os.environ["MAESTRO_PKI"] = str(TMP / "pki")
os.environ["MAESTRO_DB"] = str(TMP / "maestro.db")
os.environ["MAESTRO_POLL"] = "0"  # disable background loop during the test

PORT = 8453
sys.path.insert(0, str(ROOT))
import pki  # noqa: E402

ok = fail = 0


def check(label, cond):
    global ok, fail
    if cond:
        ok += 1; print(f"  pass  {label}")
    else:
        fail += 1; print(f"  FAIL  {label}")


def wait_port(host, port, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.15)
    return False


# 1. CA + orchestrator client cert
pki.init_ca(Path(os.environ["MAESTRO_PKI"]))
check("pki init creates CA + client cert",
      (Path(os.environ["MAESTRO_PKI"]) / "ca.crt").exists()
      and (Path(os.environ["MAESTRO_PKI"]) / "orchestrator.crt").exists())

# 2. enroll a node bound to localhost
bundle, fp = pki.enroll(Path(os.environ["MAESTRO_PKI"]), "T1", "127.0.0.1", PORT,
                        dist_root=TMP / "dist")
check("enroll builds a bundle with certs + agent",
      all((bundle / f).exists() for f in
          ("server.crt", "server.key", "ca.crt", "agent.py", "install.sh", "agent.env")))
check("enroll returns a fingerprint", len(fp) == 64)

# 3. start the real agent against that bundle
agent_env = dict(os.environ,
                 MAESTRO_AGENT_HOST="127.0.0.1",
                 MAESTRO_AGENT_PORT=str(PORT),
                 MAESTRO_AGENT_CERTDIR=str(bundle),
                 MAESTRO_NYM_PORT="59999",
                 MAESTRO_NYM_SERVICE="nonexistent.service")
proc = subprocess.Popen([sys.executable, str(ROOT / "agent" / "agent.py")],
                        env=agent_env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
try:
    check("agent port opens", wait_port("127.0.0.1", PORT))

    ca = str(Path(os.environ["MAESTRO_PKI"]) / "ca.crt")
    import ssl
    cctx = ssl.create_default_context(cafile=ca)
    cctx.load_cert_chain(
        certfile=str(Path(os.environ["MAESTRO_PKI"]) / "orchestrator.crt"),
        keyfile=str(Path(os.environ["MAESTRO_PKI"]) / "orchestrator.key"))

    # 4. direct mTLS call with the orchestrator cert
    with httpx.Client(verify=cctx, timeout=5) as c:
        r = c.get(f"https://127.0.0.1:{PORT}/v1/health")
        check("health over mTLS 200", r.status_code == 200)
        r = c.get(f"https://127.0.0.1:{PORT}/v1/status")
        body = r.json()
        check("status over mTLS 200", r.status_code == 200)
        check("status: agent reports version", body.get("agent_version") == "0.1.0")
        check("status: service inactive (no nym here)", body.get("service_active") is False)
        check("status: nym block present", isinstance(body.get("nym"), dict))

    # 5. a client WITHOUT the cert must be rejected at the TLS layer
    rejected = False
    try:
        with httpx.Client(verify=ca, timeout=5) as c:
            c.get(f"https://127.0.0.1:{PORT}/v1/status")
    except Exception:
        rejected = True
    check("uncertified client is rejected", rejected)

    # 6. full orchestrator path: register node, refresh, see cached status
    from fastapi.testclient import TestClient
    import app as appmod
    with TestClient(appmod.app) as tc:
        tc.post("/api/nodes", json={"node_id": "t1-id", "name": "T1",
                                    "ip": "127.0.0.1", "agent_port": PORT})
        r = tc.post("/api/refresh")
        summary = r.json()
        check("refresh reports one reachable", summary == {"polled": 1, "reachable": 1})
        r = tc.get("/api/nodes")
        node = r.json()[0]
        check("grid shows node reachable", node["status"] and node["status"]["reachable"] is True)
        check("grid shows service_active False", node["status"]["service_active"] is False)
        check("grid shows last_seen set", bool(node["status"]["last_seen"]))
finally:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except Exception:
        proc.kill()

print(f"\n{ok} passed, {fail} failed")
raise SystemExit(1 if fail else 0)
