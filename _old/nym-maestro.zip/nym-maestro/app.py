"""nym maestro — local orchestrator.

Runs on your Mac. Serves the dashboard and owns the node registry. Connects out
to node agents over mTLS (added in slice 2). Bind to localhost only.

    pip install -r requirements.txt
    python app.py                 # http://127.0.0.1:7766
    python app.py --addr 127.0.0.1:7766 --db ~/.nym-maestro/maestro.db
"""
import argparse
import asyncio
import contextlib
import os
import ssl
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import HTMLResponse, JSONResponse, Response
from pydantic import BaseModel

from store import Conflict, Store

VERSION = "0.1.0"
BASE = Path(__file__).resolve().parent
INDEX_HTML = (BASE / "web" / "index.html").read_bytes()
SCHEMA = (BASE / "schema.sql").read_text()


def default_db() -> str:
    return os.environ.get("MAESTRO_DB") or str(
        Path.home() / ".nym-maestro" / "maestro.db"
    )


def pki_dir() -> Path:
    return Path(os.environ.get("MAESTRO_PKI") or (Path.home() / ".nym-maestro" / "pki"))


class Pki:
    def __init__(self, d: Path):
        self.ca_cert = str(d / "ca.crt")
        self.client_cert = str(d / "orchestrator.crt")
        self.client_key = str(d / "orchestrator.key")

    def ready(self) -> bool:
        return all(Path(p).exists() for p in (self.ca_cert, self.client_cert, self.client_key))

    def mtls_context(self) -> ssl.SSLContext:
        ctx = ssl.create_default_context(cafile=self.ca_cert)
        ctx.load_cert_chain(certfile=self.client_cert, keyfile=self.client_key)
        return ctx


async def _poll_one(client: httpx.AsyncClient, node: dict):
    url = f"https://{node['ip']}:{node['agent_port']}/v1/status"
    try:
        r = await client.get(url)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


async def poll_all(app: FastAPI) -> dict:
    store, pki = app.state.store, app.state.pki
    nodes = [n for n in store.list_nodes() if n["enabled"]]
    if not nodes:
        return {"polled": 0, "reachable": 0}

    async with httpx.AsyncClient(verify=pki.mtls_context(), timeout=8.0) as client:
        results = await asyncio.gather(*[_poll_one(client, n) for n in nodes])

    reachable = 0
    for node, res in zip(nodes, results):
        if not res:
            store.upsert_status(node["node_id"], reachable=False)
            continue
        reachable += 1
        nym = res.get("nym") or {}
        store.upsert_status(
            node["node_id"], reachable=True,
            version=nym.get("version"), mode=nym.get("mode"),
            mixnode=nym.get("mixnode"), entry=nym.get("entry"),
            exit=nym.get("exit"), wireguard=nym.get("wireguard"),
            service_active=res.get("service_active"),
            fail2ban_banned=res.get("fail2ban_banned"),
        )
    return {"polled": len(nodes), "reachable": reachable}


async def _poll_loop(app: FastAPI, interval: int):
    if interval <= 0:
        return
    while True:
        try:
            if app.state.pki.ready():
                await poll_all(app)
        except Exception:
            pass
        await asyncio.sleep(interval)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db = default_db()
    Path(db).parent.mkdir(parents=True, exist_ok=True)
    app.state.store = Store(db, SCHEMA)
    app.state.pki = Pki(pki_dir())
    interval = int(os.environ.get("MAESTRO_POLL", "30"))
    task = asyncio.create_task(_poll_loop(app, interval))
    try:
        yield
    finally:
        task.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await task
        app.state.store.close()


app = FastAPI(title="nym maestro", version=VERSION, lifespan=lifespan)


# Keep the API's error shape as {"error": "..."} so the UI stays unchanged.
@app.exception_handler(HTTPException)
async def _http_exc(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"error": exc.detail})


@app.exception_handler(RequestValidationError)
async def _validation_exc(request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=400, content={"error": "invalid request body"})


class NodeCreate(BaseModel):
    node_id: str
    name: str
    ip: str
    hostname: str = ""
    agent_port: int = 8443
    agent_fp: str = ""
    service_name: str = ""
    binary_path: str = ""
    notes: str = ""
    enabled: bool = True


class NodePatch(BaseModel):
    name: str | None = None
    ip: str | None = None
    hostname: str | None = None
    agent_port: int | None = None
    agent_fp: str | None = None
    service_name: str | None = None
    binary_path: str | None = None
    notes: str | None = None
    enabled: bool | None = None


@app.get("/", response_class=HTMLResponse)
def index():
    return HTMLResponse(INDEX_HTML)


@app.get("/api/health")
def health():
    return {"status": "ok", "version": VERSION}


@app.get("/api/nodes")
def list_nodes(request: Request):
    return request.app.state.store.list_nodes()


@app.get("/api/nodes/{node_id}")
def get_node(node_id: str, request: Request):
    v = request.app.state.store.get_node(node_id)
    if v is None:
        raise HTTPException(404, "no node with that id")
    return v


@app.post("/api/nodes", status_code=201)
def create_node(n: NodeCreate, request: Request):
    node_id, name, ip = n.node_id.strip(), n.name.strip(), n.ip.strip()
    if not (node_id and name and ip):
        raise HTTPException(400, "node_id, name and ip are required")
    data = n.model_dump()
    data.update(
        node_id=node_id, name=name, ip=ip,
        hostname=n.hostname.strip(), notes=n.notes.strip(),
        service_name=n.service_name.strip(), binary_path=n.binary_path.strip(),
        agent_fp=n.agent_fp.strip(),
    )
    try:
        request.app.state.store.create_node(data)
    except Conflict as e:
        raise HTTPException(409, str(e))
    return request.app.state.store.get_node(node_id)


@app.patch("/api/nodes/{node_id}")
def update_node(node_id: str, patch: NodePatch, request: Request):
    fields = patch.model_dump(exclude_unset=True)
    for k in ("hostname", "agent_fp", "service_name", "binary_path", "notes"):
        if k in fields and isinstance(fields[k], str):
            fields[k] = fields[k].strip() or None
    for k in ("name", "ip"):
        if k in fields and isinstance(fields[k], str):
            fields[k] = fields[k].strip()
    try:
        ok = request.app.state.store.update_node(node_id, fields)
    except Conflict as e:
        raise HTTPException(409, str(e))
    if not ok:
        raise HTTPException(404, "no node with that id")
    return request.app.state.store.get_node(node_id)


@app.delete("/api/nodes/{node_id}", status_code=204)
def delete_node(node_id: str, request: Request):
    if not request.app.state.store.delete_node(node_id):
        raise HTTPException(404, "no node with that id")
    return Response(status_code=204)


@app.post("/api/refresh")
async def refresh(request: Request):
    if not request.app.state.pki.ready():
        raise HTTPException(400, "PKI not initialised — run: python pki.py init")
    return await poll_all(request.app)


def main():
    ap = argparse.ArgumentParser(prog="nym-maestro")
    ap.add_argument("--addr", default="127.0.0.1:7766", help="listen address (keep on localhost)")
    ap.add_argument("--db", default=default_db(), help="path to the SQLite database")
    args = ap.parse_args()
    os.environ["MAESTRO_DB"] = args.db
    host, _, port = args.addr.rpartition(":")

    import uvicorn
    uvicorn.run(app, host=host or "127.0.0.1", port=int(port))


if __name__ == "__main__":
    main()
