# nym maestro

Client/server control plane for a Nym node fleet. Replaces the SSH-and-expect
`nym_node_manager.sh` with a local orchestrator (your Mac) that talks to a small
agent on each node over mutual TLS — fixed command catalogue, no passwords on the
wire, no arbitrary remote root shell.

Slices 1-2 are in: the orchestrator + registry, and the node agent with live
status over mTLS. Remote write actions come next.

## Components

    app.py          orchestrator: FastAPI, serves the UI, polls agents (Mac)
    store.py        SQLite registry + cached telemetry
    pki.py          local CA + per-node enrollment (Mac)
    agent/agent.py  node agent: stdlib-only mTLS server, read-only status
    web/index.html  dashboard (vanilla JS)
    schema.sql      applied on first run

Wallet material stays in your existing ~/.nym_wallets store — never in this DB,
never on a node.

## Run the orchestrator (Mac)

Requires Python 3.11+.

    cd nym-maestro
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python app.py                 # http://127.0.0.1:7766

Flags: --addr (default 127.0.0.1:7766), --db (default ~/.nym-maestro/maestro.db).
Env:   MAESTRO_PKI (cert dir, default ~/.nym-maestro/pki),
       MAESTRO_POLL (background poll seconds, default 30; 0 disables).

## Trust model

A local CA on your Mac signs one orchestrator client cert and one server cert per
node. The agent requires a client cert signed by your CA; the orchestrator
requires a server cert signed by your CA. Nothing unsigned completes the TLS
handshake. The CA private key never leaves your Mac.

## Bring a node online (slice 2)

1. Add the node in the UI (name, IP, agent port — default 8443).
2. One-time, create the CA + orchestrator cert:

       python pki.py init

3. Enroll the node — issues its server cert and builds a deploy bundle
   (IP is looked up from the registry):

       python pki.py enroll CH01

   This prints the two commands to run, e.g.:

       scp -r dist/CH01 root@<ip>:/tmp/nym-maestro-agent
       ssh root@<ip> 'cd /tmp/nym-maestro-agent && bash install.sh'

4. Open the node's agent port (default 8443) in its firewall if one is active.
5. Click Refresh in the UI (or wait for the poll). The node goes live: version,
   roles, WireGuard, service state, fail2ban ban count.

The agent runs as its own systemd unit (`nym-maestro-agent.service`), additive to
the existing nym-node setup, discovering the installed service rather than
re-provisioning it. It is read-only this slice.

## Tests

    pip install fastapi httpx cryptography
    python smoke_test.py          # 21 checks: registry API
    python test_agent_mtls.py     # 14 checks: CA, agent, mTLS, orchestrator poll

## API

    GET    /api/health
    GET    /api/nodes                 registry joined with cached status
    POST   /api/nodes
    GET    /api/nodes/{id}
    PATCH  /api/nodes/{id}            partial; node_id is immutable
    DELETE /api/nodes/{id}
    POST   /api/refresh               poll all enabled agents over mTLS

Agent (mTLS, on each node):

    GET    /v1/health
    GET    /v1/status                 version, roles, wireguard, service, bans

## Roadmap

1. Local foundation — registry + UI.                 done
2. Agent + live status over mTLS.                    done
3. Safe write actions: restart -> upgrade -> toggle.
4. fail2ban + harden-ssh (native, no expect).
5. File ops: replace-html, then backup.
6. run_allowlisted -- gated + audited, last.
