#!/usr/bin/env python3
"""nym maestro agent — runs on each node.

Stdlib only (http.server, ssl, subprocess, urllib, json) so the fleet needs no
pip installs. Exposes a mutually-authenticated HTTPS API:

    GET /v1/health   liveness + agent version
    GET /v1/status   telemetry for the dashboard grid

Config comes from the environment (set by the systemd unit / agent.env):

    MAESTRO_AGENT_HOST      bind address           (default 0.0.0.0)
    MAESTRO_AGENT_PORT      listen port            (default 8443)
    MAESTRO_AGENT_CERTDIR   cert directory         (default /etc/nym-maestro-agent)
                            expects server.crt, server.key, ca.crt
    MAESTRO_NYM_PORT        nym-node HTTP API port (default 8080)
    MAESTRO_NYM_SERVICE     systemd unit name      (default nym-node.service)

The agent is additive: it discovers the already-installed node setup and never
re-provisions it. Write actions arrive in later slices; for now it is read-only.
"""
import json
import os
import re
import ssl
import subprocess
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

AGENT_VERSION = "0.1.0"

HOST = os.environ.get("MAESTRO_AGENT_HOST", "0.0.0.0")
PORT = int(os.environ.get("MAESTRO_AGENT_PORT", "8443"))
CERTDIR = os.environ.get("MAESTRO_AGENT_CERTDIR", "/etc/nym-maestro-agent")
NYM_PORT = int(os.environ.get("MAESTRO_NYM_PORT", "8080"))
NYM_SERVICE = os.environ.get("MAESTRO_NYM_SERVICE", "nym-node.service")


def _run(cmd, timeout=6):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except Exception:
        return 1, "", ""


def _get_json(url, timeout=2):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def read_nym():
    """Read roles/version/wireguard from the node's local nym-node HTTP API."""
    base = f"http://127.0.0.1:{NYM_PORT}/api/v1"
    out = {"version": None, "mode": None, "mixnode": None,
           "entry": None, "exit": None, "wireguard": None}
    try:
        out["version"] = _get_json(base + "/build-information").get("build_version")
    except Exception:
        pass
    try:
        roles = _get_json(base + "/roles")
        mix = bool(roles.get("mixnode_enabled"))
        gw = bool(roles.get("gateway_enabled"))
        is_exit = bool(roles.get("ip_packet_router_enabled") or roles.get("network_requester_enabled"))
        out["mixnode"] = mix
        out["exit"] = gw and is_exit
        out["entry"] = gw and not is_exit
        if mix:
            out["mode"] = "mixnode"
        elif out["exit"]:
            out["mode"] = "exit-gateway"
        elif out["entry"]:
            out["mode"] = "entry-gateway"
    except Exception:
        pass
    try:
        out["wireguard"] = _get_json(base + "/gateway").get("wireguard") is not None
    except Exception:
        pass
    return out


def unit_exists(unit):
    rc, _, _ = _run(["systemctl", "cat", unit])
    return rc == 0


def find_nym_unit():
    rc, out, _ = _run(["systemctl", "list-unit-files", "--no-legend", "nym-node*"])
    if rc == 0:
        for line in out.splitlines():
            parts = line.split()
            if parts:
                return parts[0]
    return None


def service_state():
    svc = NYM_SERVICE
    if not unit_exists(svc):
        svc = find_nym_unit() or svc
    rc, out, _ = _run(["systemctl", "is-active", svc])
    return (out.strip() == "active"), svc


def fail2ban_banned():
    rc, out, _ = _run(["fail2ban-client", "status", "sshd"])
    if rc != 0:
        return None
    m = re.search(r"Currently banned:\s*(\d+)", out)
    return int(m.group(1)) if m else None


def build_status():
    active, svc = service_state()
    return {
        "agent_version": AGENT_VERSION,
        "service_name": svc,
        "service_active": active,
        "fail2ban_banned": fail2ban_banned(),
        "nym": read_nym(),
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "nym-maestro-agent/" + AGENT_VERSION

    def _send(self, code, payload):
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/v1/health":
            self._send(200, {"status": "ok", "agent_version": AGENT_VERSION})
        elif self.path == "/v1/status":
            self._send(200, build_status())
        else:
            self._send(404, {"error": "not found"})

    def log_message(self, fmt, *args):
        # Quiet: one concise line to stderr, captured by journald.
        print("agent %s - %s" % (self.address_string(), fmt % args))


def make_ssl_context():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(os.path.join(CERTDIR, "server.crt"),
                        os.path.join(CERTDIR, "server.key"))
    ctx.load_verify_locations(os.path.join(CERTDIR, "ca.crt"))
    ctx.verify_mode = ssl.CERT_REQUIRED  # require the orchestrator's client cert
    return ctx


def main():
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    httpd.socket = make_ssl_context().wrap_socket(httpd.socket, server_side=True)
    print(f"nym maestro agent {AGENT_VERSION} listening on {HOST}:{PORT} (mTLS)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
